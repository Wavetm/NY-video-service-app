import { Global } from "@emotion/react";
const Fonts = () => (
   <Global
      styles={`
         @font-face {
            font-family: 'Matroska';
            src: url('/fonts/Matroska/Matroska.ttf') format('opentype');
         }
      `}
   />
);

export default Fonts;
