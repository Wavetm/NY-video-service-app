import React, { useState } from "react";
import {
	Box,
	Button,
	Container,
	Flex,
	Image,
	Text,
	Stack,
	Heading,
	Icon,
	HStack,
	Input,
	Link,
	Grid,
	Modal,
	ModalOverlay,
	ModalContent,
	ModalHeader,
	ModalCloseButton,
	ModalBody,
	useDisclosure,
	useToast,
} from "@chakra-ui/react";
import { FaFacebookF, FaInstagram, FaTwitter } from "react-icons/fa";
import { useInView } from "react-intersection-observer";
import ReactPlayer from "react-player";
import Head from "next/head";
import { Slider } from "../components/Slider";
import FeedBackCard from "../components/FeedBackCard";
import { useForm } from "react-hook-form";

const Banner = ({ name }) => {
	const ref = useSection(name);

	return (
		<Box
			ref={ref}
			id="main"
			height="100vh"
			backgroundImage="url('/assets/bg.jpeg')"
			backgroundPosition="center"
			backgroundSize="cover"
		>
			<Container maxW="container.lg" height="100%">
				<Flex flexDirection="column" height="100%">
					<Heading py={10} size="2xl" textAlign="center">
						NY VideoService
					</Heading>
					<Box maxW="500px" my="auto" px={10}>
						<Heading size="lg" mb={3}>
							Who we are?
						</Heading>
						<Text fontSize="xl" lineHeight="tall" mb={3}>
							We provide video service in
							<br />
							New York and New Jersey areas
							<br />
							for last 10 years.
						</Text>
						<Text fontSize={["4xl"]} fontWeight="semibold">
							347-569-4912
						</Text>
						<Text fontSize={["xl"]} fontWeight="semibold">
							vadim.elbe@yahoo.com
						</Text>
					</Box>
				</Flex>
			</Container>
		</Box>
	);
};

const ContactsForm = (props) => {
	const { register, handleSubmit, reset } = useForm();
	const [loading, setLoading] = useState(false);
	const toast = useToast();

	const onSubmit = async ({ name, email, phone, message }) => {
		const token = "2045949033:AAHuTZpgOAX8K6rAHDG1vBBflvZzLnTuacI";
		const url = `https://api.telegram.org/bot${token}/sendMessage`;
		const chatId = "496814143";

		// 637286329
		// 496814143

		try {
			setLoading(true);

			const response = await fetch(
				`${url}?chat_id=${chatId}&text=${`name: ${name}, email: ${email}, phone: ${phone}, message: ${message}`}`,
				{
					method: "POST",
				}
			);

			if (response.status === 200) {
				reset();

				toast({
					title: "Message Sent!.",
					status: "success",
					duration: 9000,
					isClosable: true,
				});
			}
		} finally {
			setLoading(false);
		}
	};

	return (
		<Stack
			justifyContent="center"
			alignItems="center"
			spacing={5}
			boxShadow="0px 0px 10px 5px #4A5568"
			bg="#060606"
			borderRadius="2xl"
			padding={[4, null, 10]}
			width="100%"
			{...props}
		>
			<Flex alignItems="center" flexDir="column">
				<Heading fontSize="24px" color="#99E836">
					Contact Us
				</Heading>
				<Text>Make your memories immortal!</Text>
			</Flex>
			<form onSubmit={handleSubmit(onSubmit)}>
				<Input
					mb="6"
					placeholder="Name"
					{...register("name", { required: true })}
				/>
				<Input
					mb="6"
					placeholder="E-mail"
					{...register("email", { required: true })}
				/>
				<Input
					mb="6"
					placeholder="Phone number"
					{...register("phone", { required: true })}
				/>
				<Input
					height="80px"
					mb="6"
					placeholder="Message"
					{...register("message")}
				/>
				<Button
					type="submit"
					size="lg"
					width="100%"
					bg="#99E836"
					_hover={{
						bg: "#79ad37",
					}}
					_active={{
						bg: "#79ad37",
					}}
					color="black"
					isDisabled={loading}
				>
					Send
				</Button>
			</form>
		</Stack>
	);
};

const fields = [
	{
		name: "Corporate Videos",
		image: "1benefContent",
		bg: "1Benefits",
	},
	{
		name: "Commercials",
		image: "2benefContent",
		bg: "3beneficts",
	},
	{
		name: "Drone filming",
		image: "3benefContent",
		bg: "1Benefits",
	},
	{
		name: "360 - degree shots",
		image: "4benefContent",
		bg: "1Benefits",
	},
];

export const About = ({ name }) => {
	const ref = useSection(name);

	return (
		<Box ref={ref} id="about">
			<Container maxW="container.lg">
				<Flex paddingY={["50px", null, "100px"]} flexDirection="column">
					<Heading marginBottom="40px" size="lg">
						What we do?
					</Heading>
					<Grid
						templateColumns={[
							"repeat(1, 1fr)",
							null,
							"repeat(2, 1fr)",
							"repeat(4, 1fr)",
						]}
						gap={[10, null, 15]}
					>
						{fields.map(({ name, image, bg }, idx) => (
							<Stack
								key={idx}
								spacing={[4, null, 6]}
								alignItems="center"
							>
								<Flex
									alignItems="center"
									justifyContent="center"
									bg={`url('/assets/${bg}.png')`}
									bgSize="cover"
									boxSize={["150px", null, "200px"]}
								>
									<Image
										src={`/assets/${image}.png`}
										boxSize={["100px", null, "150px"]}
									/>
								</Flex>
								<Text color="white" fontSize="xl">
									{name}
								</Text>
							</Stack>
						))}
					</Grid>
				</Flex>
			</Container>
		</Box>
	);
};

const Projects = ({ name, projects }) => {
	const ref = useSection(name);
	const [video, setVideo] = useState(0);
	const { isOpen, onOpen, onClose } = useDisclosure();

	return (
		<Box ref={ref} id="projects">
			<Container maxW="container.lg">
				<Flex paddingY={["50px", null, "150px"]} flexDirection="column">
					<Heading marginBottom="40px" size="xl">
						Projects
					</Heading>
					<Grid
						templateColumns={[
							"repeat(1, 1fr)",
							null,
							"repeat(2, 1fr)",
							"repeat(3, 1fr)",
						]}
						width="100%"
						rowGap={10}
						columnGap={6}
					>
						{projects.map(({ thumbnail }, idx) => (
							<Flex
								as="button"
								key={idx}
								position="relative"
								height="200px"
								border="1px solid"
								borderColor="gray.400"
								backgroundImage={thumbnail}
								backgroundPosition="center"
								backgroundSize="cover"
								onClick={() => {
									setVideo(idx);
									onOpen();
								}}
								_hover={{
									transform: "scale(1.05)",
									transition: "transform 0.3s",
								}}
							>
								<Box
									position="absolute"
									top={0}
									left={0}
									width="100%"
									height="100%"
									_after={{
										top: 0,
										left: 0,
										content: '""',
										position: "absolute",
										width: "100%",
										height: "100%",
										bg: "rgba(0, 0, 0, 0.3)",
									}}
								></Box>
								<Flex
									position="absolute"
									top={0}
									left={0}
									width="100%"
									height="100%"
									color="white"
									justifyContent="center"
									// alignItems="center"
									padding={3}
								>
									{projects[idx].name}
								</Flex>
							</Flex>
						))}
					</Grid>

					<Modal
						isOpen={isOpen}
						onClose={onClose}
						size="2xl"
						isCentered={true}
					>
						<ModalOverlay />
						<ModalContent>
							<ModalCloseButton />
							<ModalHeader>{projects[video].name}</ModalHeader>
							<ModalBody>
								<Box py={4}>
									<ReactPlayer
										key={projects[video].link}
										url={projects[video].link}
										controls={true}
										width="100%"
									/>
								</Box>
							</ModalBody>
						</ModalContent>
					</Modal>
				</Flex>
			</Container>
		</Box>
	);
};

{
	/* <Stack direction="row" spacing={10} mb={20}>
   <ReactPlayer
      key={projects[video].link}
      url={projects[video].link}
      controls={true}
   />
   <Heading
      size="lg"
      display={["none", null, "block"]}
      width="40%"
   >
      {projects[video].name}
   </Heading>
</Stack>
<Stack pb={10} borderY="1px solid white">
   <Heading size="md" my={4}>
      Other projects
   </Heading>
   <Slider
      spacing={40}
      items={projects.map(({ thumbnail }, idx) => (
         <Box
            as="button"
            key={idx}
            width="200px"
            height="150px"
            className="keen-slider__slide"
            backgroundImage={thumbnail}
            backgroundSize="cover"
            backgroundPosition="center"
            backgroundRepeat="no-repeat"
            border="1px solid"
            borderColor="gray.400"
            onClick={() => {
               setVideo(idx);
            }}
         />
      ))}
   />
</Stack> */
}

const testimonals = [
	{
		desc:
			"We make our customers  products valuable in the eyes of customers. Todo this, we analyze and study people, build long-term strategies for interacting with them, develop creative ideas our customers products valuable in the eyes of",
		name: "Dwight Schrute",
		company: "Creative Market inc.",
	},
	{
		desc:
			"We make our customers  products valuable in the eyes of customers. Todo this, we analyze and study people, build long-term strategies for interacting with them, develop creative ideas our customers products valuable in the eyes of",
		name: "Dwight Schrute",
		company: "Creative Market inc.",
	},
	{
		desc:
			"We make our customers  products valuable in the eyes of customers. Todo this, we analyze and study people, build long-term strategies for interacting with them, develop creative ideas our customers products valuable in the eyes of",
		name: "Dwight Schrute",
		company: "Creative Market inc.",
	},
	{
		desc:
			"We make our customers  products valuable in the eyes of customers. Todo this, we analyze and study people, build long-term strategies for interacting with them, develop creative ideas our customers products valuable in the eyes of",
		name: "Dwight Schrute",
		company: "Creative Market inc.",
	},
];

const Testimonals = ({ name }) => {
	const ref = useSection(name);

	return (
		<Box
			ref={ref}
			id="feedback"
			position="relative"
			bgColor="#030308"
			d="flex"
			_after={{
				content: "''",
				position: "absolute",
				top: 0,
				left: 0,
				right: 0,
				bottom: 0,
				width: "100%",
				height: "100%",
				backgroundImage: "url('/assets/FeedbackBG.png')",
				backgroundPosition: "center",
				backgroundSize: "cover",
			}}
		>
			<Container maxW="container.lg">
				<Flex
					paddingY={["50px", null, "150px"]}
					justifyContent="flex-end"
					alignItems="center"
				>
					<Box zIndex="2" w={["100%", null, "50%"]}>
						<Heading pb={["40px"]} size="xl">
							What people say about us?
						</Heading>
						<Slider
							slidesCount={{ base: 1, md: 1 }}
							items={testimonals.map(({ desc, name, company }, idx) => (
								<FeedBackCard
									key={idx}
									name={name}
									desc={desc}
									company={company}
								/>
							))}
						/>
					</Box>
				</Flex>
			</Container>
		</Box>
	);
};

const Contacts = ({ name }) => {
	const ref = useSection(name);

	return (
		<Box ref={ref} id="contacts">
			<Container maxW="container.lg">
				<Stack
					paddingY={["50px", null, "150px"]}
					direction={["column-reverse", null, "row"]}
					spacing={16}
				>
					<ContactsForm />
					<Stack spacing={7} marginTop={["50px", "30px", "0", null]}>
						<Heading size="xl">We keep your best memories</Heading>
						<Box
							bg='url("/assets/contactsFire.png")'
							bgSize="cover"
							height={["200px", null, "350px", null]}
						>
							<Text fontSize="lg" lineHeight="tall">
								We make you memories immortal and unforgettable. By
								bringing our ideas to life we create the best solution
								to your business/project/channel giving it the most
								attractive view
							</Text>
						</Box>
					</Stack>
				</Stack>
			</Container>
		</Box>
	);
};

const Footer = () => {
	return (
		<Box bgColor="black" marginTop={["50px", null, "100px"]}>
			<Container maxW="container.lg">
				<Flex flexDirection="column">
					<Heading fontSize={["lg", null, "xl"]} mb={6}>
						NY VideoService
					</Heading>
					<Flex
						justifyContent="space-between"
						alignItems="center"
						borderBottom="1px solid #71777D"
						paddingBottom={10}
					>
						<Stack
							spacing={[5, null, 10]}
							direction={["column", null, "row"]}
						>
							{links.map(({ link, title }, idx) => (
								<Link key={idx} href={link}>
									{title}
								</Link>
							))}
						</Stack>
						<Stack>
							<HStack spacing={4} justifyContent="flex-end">
								<Link isExternal href={"/"}>
									<a>
										<Icon
											_hover={{
												paddingBottom: "2px",
												borderBottom: "2px solid #7CC0E9",
											}}
											as={FaFacebookF}
											color="white"
											boxSize={4}
										/>
									</a>
								</Link>
								<Link isExternal href={"/"}>
									<a>
										<Icon
											_hover={{
												paddingBottom: "2px",
												borderBottom: "2px solid #7CC0E9",
											}}
											as={FaInstagram}
											color="white"
											boxSize={4}
										/>
									</a>
								</Link>
								<Link isExternal href={"/"}>
									<a>
										<Icon
											_hover={{
												paddingBottom: "2px",
												borderBottom: "2px solid #7CC0E9",
											}}
											as={FaTwitter}
											color="white"
											boxSize={4}
										/>
									</a>
								</Link>
							</HStack>
						</Stack>
					</Flex>
					<Flex
						paddingY={[6, null, 10]}
						justifyContent="space-between"
						flexWrap="wrap"
					>
						<Text color="#92989F" fontSize={["xs", null, "sm"]}>
							Developed by © Rearm.dev 2021. <br /> All right reserved
						</Text>
					</Flex>
				</Flex>
			</Container>
		</Box>
	);
};

const links = [
	{
		link: "#main",
		title: "Who we are",
		section: "main",
	},
	{
		link: "#about",
		title: "What we do",
		section: "about",
	},
	{
		link: "#projects",
		title: "Our projects",
		section: "projects",
	},
	{
		link: "#feedback",
		title: "Testimonals",
		section: "feedback",
	},
	{
		link: "#contacts",
		title: "Contact Us",
		section: "contacts",
	},
];

const Navigation = () => {
	const { section } = React.useContext(Context);

	return (
		<Flex
			pos="fixed"
			height="100vh"
			flexDirection="column"
			justifyContent="space-evenly"
			zIndex="16"
			marginLeft={["-30px", null, null, 0]}
		>
			{links.map(({ link, title, section: s }) => (
				<Link
					href={link}
					key={title}
					color={section === s ? "white" : "gray.400"}
					borderBottom="1px solid transparent"
					borderBottomColor={section === s ? "#18A0FB" : "transparent"}
					_hover={{
						color: "white",
						borderBottom: "1px solid #18A0FB",
						padding: "0",
					}}
					transform="rotate(90deg)"
					transition="0.3s all"
				>
					{title}
				</Link>
			))}
		</Flex>
	);
};

const Context = React.createContext();

function ContextProvider({ children }) {
	const [section, setSection] = React.useState("main");
	const value = { section, setSection };
	return <Context.Provider value={value}>{children}</Context.Provider>;
}

function useSection(section) {
	const { setSection } = React.useContext(Context);
	const { ref, inView } = useInView({
		threshold: 0.5,
	});

	React.useEffect(() => {
		if (inView) {
			setSection(section);
		}
	}, [inView]);

	return ref;
}

const videos = [
	{
		name: "LIU Pharmacy Graduation 2017",
		link: "https://www.dailymotion.com/video/x7k5zpv",
	},
	{
		name: "Shaun is 2 !!! Happy Birthday !!!",
		link: "https://www.dailymotion.com/video/x7k5z76",
	},
	{
		name: "L and J B'nai Mitzvah",
		link: "https://www.dailymotion.com/video/x7k5yjb",
	},
	{
		name: "Julia's Bat Mitzvah",
		link: "https://www.dailymotion.com/video/x7k5y0e",
	},
	{
		name: "Kristina and Kirill",
		link: "https://www.dailymotion.com/video/x7k5wy5",
	},
];

export async function getStaticProps() {
	let projects = videos.map(async (video) => {
		const videoId = video.link.split("/").pop();

		const res = await fetch(
			`https://api.dailymotion.com/video/${videoId}?fields=thumbnail_large_url`
		);

		const data = await res.json();

		return {
			...video,
			thumbnail: data.thumbnail_large_url,
		};
	});

	projects = await Promise.all(projects);

	return {
		props: {
			projects,
		},
	};
}

export default function Home({ projects }) {
	return (
		<>
			<Head>
				<title>NY Video Service</title>
			</Head>
			<ContextProvider>
				<Box bg="#030303" color="white">
					{/* <Header /> */}
					<Navigation />
					<Banner name="main" />
					<About name="about" />
					<Projects name="projects" projects={projects} />
					<Testimonals name="feedback" />
					<Contacts name="contacts" />
					<Footer />
				</Box>
			</ContextProvider>
		</>
	);
}
